package com.proyectodsansor.dsansor_aplicativo_web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsansorAplicativoWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsansorAplicativoWebApplication.class, args);
	}

}
