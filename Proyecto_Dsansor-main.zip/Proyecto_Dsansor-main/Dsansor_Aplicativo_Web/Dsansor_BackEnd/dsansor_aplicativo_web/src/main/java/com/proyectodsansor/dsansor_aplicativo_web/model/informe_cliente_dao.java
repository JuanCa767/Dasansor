package com.proyectodsansor.dsansor_aplicativo_web.model;

public class informe_cliente_dao {

}