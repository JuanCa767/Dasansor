package com.proyectodsansor.dsansor_aplicativo_web.model;

public class usuarios_dao {

}