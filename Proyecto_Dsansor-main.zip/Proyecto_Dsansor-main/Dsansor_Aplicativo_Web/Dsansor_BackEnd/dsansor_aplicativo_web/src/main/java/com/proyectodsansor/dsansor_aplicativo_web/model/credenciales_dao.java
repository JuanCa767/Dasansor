package com.proyectodsansor.dsansor_aplicativo_web.model;

public class credenciales_dao {

}