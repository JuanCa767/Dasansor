package com.proyectodsansor.dsansor_aplicativo_web.service;

public class informe_cliente_service {

}