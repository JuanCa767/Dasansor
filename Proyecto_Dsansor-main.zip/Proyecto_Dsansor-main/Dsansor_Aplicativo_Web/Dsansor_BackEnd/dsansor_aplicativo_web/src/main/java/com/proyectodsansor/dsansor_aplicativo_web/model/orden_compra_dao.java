package com.proyectodsansor.dsansor_aplicativo_web.model;

public class orden_compra_dao {

}